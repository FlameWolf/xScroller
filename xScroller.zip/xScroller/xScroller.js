﻿"use strict";
(function($) {
	var emptyString = String().constructor("");
	var sourceDirectory = (function() {
		var scriptElements = document.getElementsByTagName("script");
		var currentScriptElement = scriptElements[(scriptElements.length - 1)];
		var currentScriptSource = (currentScriptElement.src || emptyString);
		return currentScriptSource.substr(0, currentScriptSource.lastIndexOf("/"));
	})();
	var scrollableElementArray = new Array();
	var getLimitedScrollBarTop = function(scrollBar, suggestedTop) {
		var scrollBarHolder = scrollBar.parent();
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		var scrollBarHeight = scrollBar.outerHeight();
		var scrollBarHolderHeight = scrollBarHolder.height();
		var scrollBarMaxTop = (scrollBarHolderHeight - scrollBarHeight);
		if(scrollBarMaxTop < 0)
			scrollBarMaxTop = 0;
		if(suggestedTop < 0)
			suggestedTop = 0;
		else if(suggestedTop > scrollBarMaxTop)
			suggestedTop = scrollBarMaxTop;
		scrollBarHolder = null;
		return suggestedTop;
	};
	var calculateScrollBarOuterHeight = function(scrollBar, height) {
		return scrollBar.clone().css("height", (height.toString() + "px")).outerHeight();
	}
	var updateScrollContentAndScrollBarPositions = function(scrollContentHolder, offset) {
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollBar = scrollContentHolder.children(".xscroll-scrollbar-holder").first().children(".xscroll-scrollbar").first();
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		var calculatedScrollBarTop = getLimitedScrollBarTop(scrollBar, (scrollBarTop - offset));
		scrollBar.css("top", (calculatedScrollBarTop.toString() + "px"));
		scrollContent.css("top", ((0 - (calculatedScrollBarTop * scrollContent.data("xscroll-scroll-ratio"))).toString() + "px"));
		scrollBar = null;
		scrollContent = null;
	};
	var updateScrollContentPosition = function(scrollContentHolder, offset) {
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollBar = scrollContentHolder.children(".xscroll-scrollbar-holder").first().children(".xscroll-scrollbar").first();
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		var calculatedScrollBarTop = getLimitedScrollBarTop(scrollBar, (scrollBarTop - offset));
		scrollContent.css("top", ((0 - (calculatedScrollBarTop * scrollContent.data("xscroll-scroll-ratio"))).toString() + "px"));
		scrollBar = null;
		scrollContent = null;
	};
	var updateScrollBarPosition = function(scrollContentHolder) {
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollBarHolder = scrollContentHolder.children(".xscroll-scrollbar-holder").first();
		var scrollBar = scrollBarHolder.children(".xscroll-scrollbar").first();
		var scrollContentTop = parseInt(scrollContent.css("top") || 0);
		scrollBar.css("top", ((0 - (scrollContentTop / scrollContent.data("xscroll-scroll-ratio"))).toString() + "px"));
		scrollBar = null;
		scrollBarHolder = null;
		scrollContent = null;
	};
	var scrollBarMouseDown = function(event) {
		if(event.which == 1) {
			var scrollBar = $(this);
			var documentElement = $(document);
			documentElement.data("xscroll-drag-element", scrollBar);
			scrollBar.data("xscroll-mousedown-event-occurred", true);
			scrollBar.data("xscroll-mousedown-top", (parseInt(scrollBar.css("top"), 10) || 0));
			scrollBar.data("xscroll-mousedown-y", event.pageY);
			documentElement.on("mousemove", scrollBarMouseMove);
			documentElement.on("mouseup", scrollBarMouseUp);
			event.preventDefault();
			documentElement = null;
			scrollBar = null;
		}
	};
	var scrollBarMouseMove = function(event) {
		if(event.which == 1) {
			var documentElement = $(document);
			var scrollBar = documentElement.data("xscroll-drag-element");
			if(scrollBar != undefined) {
				if(scrollBar.data("xscroll-mousedown-event-occurred")) {
					var scrollContentHolder = scrollBar.parent().closest(".xscroll-scroll-content-holder");
					var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
					var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
					var distanceMoved = (event.pageY - scrollBar.data("xscroll-mousedown-y"));
					var calculatedScrollBarTop = getLimitedScrollBarTop(scrollBar, (scrollBar.data("xscroll-mousedown-top") + distanceMoved));
					scrollBar.css("top", (calculatedScrollBarTop.toString() + "px"));
					updateScrollContentPosition(scrollContentHolder, (scrollBarTop - calculatedScrollBarTop));
					scrollContent = null;
					scrollContentHolder = null;
				}
			}
			event.preventDefault();
			scrollBar = null;
			documentElement = null;
		}
	};
	var scrollBarMouseUp = function(event) {
		if(event.which == 1) {
			var documentElement = $(document);
			var scrollBar = documentElement.data("xscroll-drag-element");
			if(scrollBar != undefined) {
				if(scrollBar.data("xscroll-mousedown-event-occurred")) {
					scrollBar.removeData("xscroll-mousedown-y");
					scrollBar.removeData("xscroll-mousedown-top");
					scrollBar.removeData("xscroll-mousedown-event-occurred");
					documentElement.off("mouseup", scrollBarMouseUp);
					documentElement.off("mousemove", scrollBarMouseMove);
					documentElement.removeData("xscroll-drag-element");
				}
			}
			event.preventDefault();
			scrollBar = null;
			documentElement = null;
		}
	};
	var scrollBarTouchStart = function(event) {
		var scrollBar = $(this);
		scrollBar.data("xscroll-touchstart-top", (parseInt(scrollBar.css("top"), 10) || 0));
		scrollBar.data("xscroll-touchstart-y", event.originalEvent.changedTouches[0].clientY);
		event.preventDefault();
		scrollBar = null;
	};
	var scrollBarTouchMove = function(event) {
		var scrollBar = $(this);
		var scrollContentHolder = scrollBar.parent().closest(".xscroll-scroll-content-holder");
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		var distanceMoved = (event.originalEvent.changedTouches[0].clientY - scrollBar.data("xscroll-touchstart-y"));
		var calculatedScrollBarTop = getLimitedScrollBarTop(scrollBar, (scrollBar.data("xscroll-touchstart-top") + distanceMoved));
		scrollBar.css("top", (calculatedScrollBarTop.toString() + "px"));
		updateScrollContentPosition(scrollContentHolder, (scrollBarTop - calculatedScrollBarTop));
		event.preventDefault();
		scrollContent = null;
		scrollContentHolder = null;
		scrollBar = null;
	};
	var scrollBarTouchEnd = function(event) {
		var scrollBar = $(this);
		scrollBar.removeData("xscroll-touchstart-top");
		scrollBar.removeData("xscroll-touchstart-y");
		event.preventDefault();
		scrollBar = null;
	};
	var scrollButtonPress = function(event) {
		if((event.which == 1) || (event.type == "touchstart")) {
			var scrollButton = $(this);
			var documentElement = $(document);
			documentElement.data("xscroll-press-element", scrollButton);
			scrollButton.data("xscroll-press-event-occurred", true);
			documentElement.data("xscroll-press-interval-handle", setInterval(function() {
				scrollButtonHold();
			}, 100));
			documentElement.on("mouseup", scrollButtonRelease);
			event.preventDefault();
			documentElement = null;
			scrollButton = null;
		}
	};
	var scrollButtonRelease = function(event) {
		if((event.which == 1) || (event.type == "touchend")) {
			var documentElement = $(document);
			var scrollButton = documentElement.data("xscroll-press-element");
			if(scrollButton != undefined) {
				clearInterval(documentElement.data("xscroll-press-interval-handle"));
				documentElement.removeData("xscroll-press-interval-handle");
				scrollButton.removeData("xscroll-press-event-occurred");
				documentElement.removeData("xscroll-press-element");
			}
			documentElement.off("mouseup", scrollButtonRelease);
			event.preventDefault();
			scrollButton = null;
			documentElement = null;
		}
	};
	var scrollButtonHold = function() {
		var documentElement = $(document);
		var scrollButton = documentElement.data("xscroll-press-element");
		if(scrollButton != undefined)
			if(scrollButton.data("xscroll-press-event-occurred"))
				scrollButtonClick(scrollButton);
		scrollButton = null;
		documentElement = null;
	};
	var scrollButtonClick = function(scrollButton) {
		var scrollBar = scrollButton.siblings(".xscroll-scrollbar").first();
		var scrollContentHolder = scrollButton.parent().closest(".xscroll-scroll-content-holder");
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollAmount = (scrollBar.outerHeight() / scrollContent.data("xscroll-scroll-ratio"));
		if(scrollButton.hasClass("xscroll-scroll-button-up"))
			updateScrollContentAndScrollBarPositions(scrollContentHolder, scrollAmount);
		else if(scrollButton.hasClass("xscroll-scroll-button-down"))
			updateScrollContentAndScrollBarPositions(scrollContentHolder, (0 - scrollAmount));
		scrollContent = null;
		scrollContentHolder = null;
		scrollBar = null;
	};
	var makeScrollBarDraggable = function(scrollBar) {
		scrollBar.on("mousedown", scrollBarMouseDown);
		scrollBar.on("mousemove", scrollBarMouseMove);
		scrollBar.on("mouseup", scrollBarMouseUp);
		if("ontouchstart" in window) {
			scrollBar.on("touchstart", scrollBarTouchStart);
			scrollBar.on("touchmove", scrollBarTouchMove);
			scrollBar.on("touchend", scrollBarTouchEnd);
		}
	};
	var updateScrollBarJumpPosition = function(event) {
		var scrollBarHolder = $(this);
		var scrollBar = scrollBarHolder.children(".xscroll-scrollbar").first();
		var relativeYPosition = (event.pageY - (scrollBarHolder.offset().top + (parseInt(scrollBarHolder.css("padding-top"), 0) || 0)));
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		var scrollBarBottom = scrollBarTop + scrollBar.height();
		var offset = 0;
		if(relativeYPosition > scrollBarBottom)
			offset = (scrollBarBottom - relativeYPosition);
		else if(relativeYPosition < scrollBarTop)
			offset = (scrollBarTop - relativeYPosition);
		scrollBarHolder.data("xscroll-jump-position", offset);
		scrollBar = null;
		scrollBarHolder = null;
	};
	var jumpScrollBarToPosition = function(event) {
		var scrollBarHolder = $(this);
		var scrollContentHolder = scrollBarHolder.closest(".xscroll-scroll-content-holder");
		var scrollBarJumpPosition = scrollBarHolder.data("xscroll-jump-position");
		if(scrollBarJumpPosition != undefined) {
			updateScrollContentAndScrollBarPositions(scrollContentHolder, scrollBarJumpPosition);
			scrollBarHolder.removeData("xscroll-jump-position");
		}
		event.stopPropagation();
		scrollBarJumpPosition = null;
		scrollContentHolder = null;
		scrollBarHolder = null;
	};
	var scrollOnMouseWheel = function(event, delta) {
		if(!event.originalEvent.ctrlKey) {
			var currentElement = $(this);
			var scrollContentHolder = currentElement.children(".xscroll-scroll-content-holder").first();
			var scrollBarHolder = scrollContentHolder.children(".xscroll-scrollbar-holder").first();
			var scrollBar = scrollBarHolder.children(".xscroll-scrollbar").first();
			if(!scrollBarHolder.is(":visible"))
				return;
			var scrollBarHeight = scrollBar.outerHeight();
			var scrollBarHolderHeight = scrollBarHolder.height();
			updateScrollContentAndScrollBarPositions(scrollContentHolder, (event.deltaY * (20 * (scrollBarHeight / scrollBarHolderHeight))));
			event.preventDefault();
			event.stopPropagation();
			scrollBar = null;
			scrollBarHolder = null;
			scrollContentHolder = null;
			currentElement = null;
		}
	};
	var updateXScroller = function(element) {
		var currentElement = $(element);
		var settings = currentElement.data("xscroll-settings");
		var scrollContentHolder = currentElement.children(".xscroll-scroll-content-holder").first();
		var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
		var scrollBarHolder = scrollContentHolder.children(".xscroll-scrollbar-holder").first();
		var scrollBar = scrollBarHolder.children(".xscroll-scrollbar").first();
		var scrollContentHolderHeight = scrollContentHolder.height();
		var scrollContentHeight = scrollContent.outerHeight();
		var scrollBarHolderHeight = scrollBarHolder.height();
		var heightDifference = (scrollContentHeight - scrollContentHolderHeight);
		if(heightDifference <= 0) {
			heightDifference = 0;
			scrollBar.css("top", "0");
			scrollBar.css("height", "100%");
			scrollContent.css("top", "0");
			scrollBarHolder.hide();
		}
		else {
			var scrollContentTop = (parseInt(scrollContent.css("top"), 10) || 0);
			var scrollDifference = (heightDifference + scrollContentTop);
			if(scrollDifference < 0)
				scrollContent.css("top", ((scrollContentTop - scrollDifference).toString() + "px"));
			scrollBarHolder.show();
		}
		var scrollBarHeight = calculateScrollBarOuterHeight(scrollBar, scrollBarHolderHeight - heightDifference);
		scrollBar.css("height", ((scrollBarHeight <= scrollBarHolderHeight) ? (scrollBarHeight.toString() + "px") : "100%"));
		var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
		scrollBarHeight = scrollBar.outerHeight();
		var scrollRatio = ((scrollContentHeight - scrollContentHolderHeight) / (scrollBarHolderHeight - scrollBarHeight));
		scrollContent.data("xscroll-scroll-ratio", scrollRatio);
		updateScrollBarPosition(scrollContentHolder);
		if(settings.updateOnContentResize)
			currentElement.data("xscroll-scroll-content-height", scrollContentHeight);
		if(settings.updateOnResize)
			currentElement.data("xscroll-scroll-height", currentElement.height());
		scrollBar = null;
		scrollBarHolder = null;
		scrollContent = null;
		scrollContentHolder = null;
		settings = null;
		currentElement = null;
	};
	var watchElementsForResize = function() {
		$.each(scrollableElementArray, function(index, value) {
			var currentElement = $(value);
			var xScrollSettings = currentElement.data("xscroll-settings");
			if(xScrollSettings.updateOnContentResize) {
				var oldContentWidth = currentElement.data("xscroll-scroll-content-width");
				var oldContentHeight = currentElement.data("xscroll-scroll-content-height");
				var scrollContent = currentElement.children(".xscroll-scroll-content-holder").first().children(".xscroll-scroll-content").first();
				var currentContentWidth = scrollContent.outerWidth();
				var currentContentHeight = scrollContent.outerHeight();
				if((oldContentWidth != currentContentWidth) || (oldContentHeight != currentContentHeight)) {
					currentElement.data("xscroll-scroll-content-height", currentContentHeight);
					updateXScroller(currentElement);
				}
				scrollContent = null;
				oldContentHeight = null;
				oldContentWidth = null;
			}
			if(xScrollSettings.updateOnResize) {
				var oldWidth = currentElement.data("xscroll-scroll-width");
				var oldHeight = currentElement.data("xscroll-scroll-height");
				var currentWidth = currentElement.width();
				var currentHeight = currentElement.height();
				if((oldWidth != currentWidth) || (oldHeight != currentHeight)) {
					currentElement.data("xscroll-scroll-height", currentHeight);
					updateXScroller(currentElement);
				}
				oldHeight = null;
				oldWidth = null;
			}
			xScrollSettings = null;
			currentElement = null;
		});
	};
	var createXScrollContentHolder = function(element, addButtons) {
		var jQueryWrappedElement = $(element);
		var contents = jQueryWrappedElement.contents();
		jQueryWrappedElement.append("<div class=\"xscroll-scroll-content-holder\"><div class=\"xscroll-scroll-content\"></div><div class=\"xscroll-scrollbar-holder xscroll-scrollbar-holder-button-padded\">"
			+ (addButtons ? "<div class=\"xscroll-scroll-button xscroll-scroll-button-up\"><img class=\"xscroll-scroll-arrow\" src=\"" + sourceDirectory + "/arrow-up-grey-small.png\"/></div>" : emptyString)
			+ "<div class=\"xscroll-scrollbar\"></div>"
			+ (addButtons ? "<div class=\"xscroll-scroll-button xscroll-scroll-button-down\"><img class=\"xscroll-scroll-arrow\" src=\"" + sourceDirectory + "/arrow-down-grey-small.png\"/></div>" : emptyString)
			+ "</div></div>");
		var scrollContentHolder = jQueryWrappedElement.children(".xscroll-scroll-content-holder").first();
		contents.appendTo(scrollContentHolder.children().first());
		contents = null;
		jQueryWrappedElement = null;
		return scrollContentHolder;
	};
	var removeXScroller = function(jQueryObject) {
		jQueryObject.each(function(index, value) {
			var scrollableElementIndex = $.inArray(value, scrollableElementArray);
			if(scrollableElementIndex > -1) {
				scrollableElementArray.splice(scrollableElementIndex, 1);
				var currentElement = $(value);
				var xScrollContentHolder = currentElement.children(".xscroll-scroll-content-holder").first();
				var xScrollInnerContents = xScrollContentHolder.children(".xscroll-scroll-content").first().contents();
				xScrollInnerContents.appendTo(currentElement);
				xScrollContentHolder.remove();
				xScrollInnerContents = null;
				xScrollContentHolder = null;
				currentElement = null;
			}
		});
	};
	$.fn.xScroller = function(options) {
		if(options == "destroy")
			removeXScroller(this);
		else {
			var settings = $.extend({
				showButtons: false,
				showBesideContent: false,
				updateOnResize: false,
				updateOnContentResize: false
			}, options);
			this.each(function(index, value) {
				if($.inArray(value, scrollableElementArray) == -1)
				{
					var currentElement = $(value);
					currentElement.data("xscroll-settings", settings);
					var scrollContentHolder = createXScrollContentHolder(value, settings.showButtons);
					var scrollContent = scrollContentHolder.children(".xscroll-scroll-content").first();
					var scrollBarHolder = scrollContentHolder.children(".xscroll-scrollbar-holder").first();
					var scrollBar = scrollBarHolder.children(".xscroll-scrollbar").first();
					if(settings.showButtons) {
						var scrollButtons = scrollBarHolder.children(".xscroll-scroll-button");
						scrollButtons.on("mousedown touchstart", scrollButtonPress);
						scrollButtons.on("mouseup touchend", scrollButtonRelease);
						scrollButtons.click(function(event) {
							scrollButtonClick($(this));
							event.stopPropagation();
						});
						scrollButtons = null;
					}
					else
						scrollBarHolder.removeClass("xscroll-scrollbar-holder-button-padded");
					if(settings.showBesideContent)
						scrollContent.css("padding-right", (scrollBarHolder.outerWidth().toString() + "px"));
					var scrollContentHolderHeight = scrollContentHolder.height();
					var scrollContentHeight = scrollContent.outerHeight();
					var scrollBarHolderHeight = scrollBarHolder.height();
					var heightDifference = (scrollContentHeight - scrollContentHolderHeight);
					if(heightDifference <= 0) {
						scrollBar.css("top", "0");
						scrollBar.css("height", "100%");
						scrollContent.css("top", "0");
						scrollBarHolder.hide();
					}
					var scrollBarHeight = calculateScrollBarOuterHeight(scrollBar, scrollBarHolderHeight - heightDifference);
					scrollBar.css("height", ((scrollBarHeight <= scrollBarHolderHeight) ? (scrollBarHeight.toString() + "px") : "100%"));
					var scrollBarTop = (parseInt(scrollBar.css("top"), 10) || 0);
					var scrollBarHeight = scrollBar.outerHeight();
					var scrollBarHolderHeight = scrollBarHolder.height();
					var scrollRatio = ((scrollContentHeight - scrollContentHolderHeight) / (scrollBarHolderHeight - scrollBarHeight));
					scrollContent.data("xscroll-scroll-ratio", scrollRatio);
					updateScrollBarPosition(scrollContentHolder);
					makeScrollBarDraggable(scrollBar);
					scrollBarHolder.mousemove(updateScrollBarJumpPosition);
					scrollBarHolder.click(jumpScrollBarToPosition);
					currentElement.mousewheel(scrollOnMouseWheel);
					if(settings.updateOnContentResize) {
						currentElement.data("xscroll-scroll-content-width", scrollContent.outerWidth());
						currentElement.data("xscroll-scroll-content-height", scrollContentHeight);
					}
					if(settings.updateOnResize) {
						currentElement.data("xscroll-scroll-width", currentElement.width());
						currentElement.data("xscroll-scroll-height", currentElement.height());
					}
					scrollableElementArray.push(value);
					scrollBar = null;
					scrollBarHolder = null;
					scrollContent = null;
					scrollContentHolder = null;
					currentElement = null;
				}
				else
					updateXScroller(value);
			});
		}
		return this;
	};
	setInterval(function() {
		watchElementsForResize();
	}, 100);
}(jQuery));